/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author < Leticia e Mylena >
 */
public class BD {
    private static  ArrayList<Cadastro>cadastro=new ArrayList<Cadastro>();
    private static ArrayList<Denuncia>denuncia=new ArrayList<Denuncia>();
    private static ArrayList<Dica>dica=new ArrayList<Dica>();

    /**
     * @return the cadastro
     */
    public static ArrayList<Cadastro> getCadastro() {
        return cadastro;
    }

    /**
     * @param aCadastro the cadastro to set
     */
    public static void setCadastro(ArrayList<Cadastro> aCadastro) {
        cadastro = aCadastro;
    }

    /**
     * @return the denuncia
     */
    public static ArrayList<Denuncia> getDenuncia() {
        return denuncia;
    }

    /**
     * @param aDenuncia the denuncia to set
     */
    public static void setDenuncia(ArrayList<Denuncia> aDenuncia) {
        denuncia = aDenuncia;
    }

    /**
     * @return the dica
     */
    public static ArrayList<Dica> getDica() {
        return dica;
    }

    /**
     * @param aDica the dica to set
     */
    public static void setDica(ArrayList<Dica> aDica) {
        dica = aDica;
    }
    
    
}
