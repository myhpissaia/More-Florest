/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author < Leticia e Mylena >
 */
public class Denuncia {

    private Long id;
    private String end;
    private String des;
    private String gravidade;
    private String mate;
    private String imagem;

    public Denuncia(String end, String des, String gravidade, String mate,
            String imagem) {
        this.end = end;
        this.des = des;
        this.gravidade = gravidade;
        this.mate = mate;
        this.imagem = imagem;
    }

    public Denuncia(Long id,String end, String des, String gravidade, String mate,
            String imagem) {
        this.end = end;
        this.des = des;
        this.gravidade = gravidade;
        this.mate = mate;
        this.imagem = imagem;
        this.id= id;
    }
    
    public Denuncia() {

    }

    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getImagem() {
        return imagem;
    }
    
    public void setImagem(String imagem) {
        this.imagem = imagem;
    }
    
    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getGravidade() {
        return gravidade;
    }

    public void setGravidade(String gravidade) {
        this.gravidade = gravidade;
    }

    public String getMate() {
        return mate;
    }

    public void setMate(String mate) {
        this.mate = mate;
    }

    public void MostrarDenuncia() {
        System.out.println("");
        System.out.println("DENUNCIA");
        System.out.println("Endereco:" + getEnd());
        System.out.println("Descricao:" + getDes());
        System.out.println("Gravidade:" + getGravidade());
        System.out.println("Material:" + getMate());
        System.out.println("");
    }

  

}
