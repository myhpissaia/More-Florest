/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author < Leticia e Mylena >
 */
public class Dica {

    private Long id;
    private String material;
    private String dica;

    public Dica(String material, String dica) {
        this.material = material;
        this.dica = dica;
    }

    public Dica(Long id, String material, String dica) {
        this.id = id;
        this.material = material;
        this.dica = dica;
    }

    public Dica() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getDica() {
        return dica;
    }

    public void setDica(String dica) {
        this.dica = dica;
    }

    public void MostrarDica() {
        System.out.println("");
        System.out.println("DICA");
        System.out.println("ID" + getId());
        System.out.println("Material:" + getMaterial());
        System.out.println("Dica:" + getDica());
        System.out.println("");
    }

}
