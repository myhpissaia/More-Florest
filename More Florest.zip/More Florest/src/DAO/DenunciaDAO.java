/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Cadastro;
import Model.Denuncia;
import Model.Dica;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author < Leticia e Mylena >
 */
public class DenunciaDAO {

    private Connection conexao;

    public DenunciaDAO() {
        this.conexao = new ConnectionFactory().getConnection();
    }

    public void insereDenuncia(Denuncia u) {
        try {
            String sql = "INSERT INTO denuncia (endereco,descricao,gravidade,material,imagem) VALUES (?,?,?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, u.getEnd());
            stmt.setString(2, u.getDes());
            stmt.setString(3, u.getGravidade());
            stmt.setString(4, u.getMate());
            stmt.setString(5, u.getImagem());

            stmt.execute();
            conexao.close();

        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean update(Denuncia u) {
        try {
            String sql = "UPDATE denuncia SET endereco=?,descricao=?gravidade=?,material=?,imagem=? WHERE id_denuncia =?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, u.getEnd());
            stmt.setString(2, u.getDes());
            stmt.setString(3, u.getGravidade());
            stmt.setString(4, u.getMate());
            stmt.setString(5, u.getImagem());
            stmt.setLong(6, u.getId());

            stmt.execute();
            conexao.close();
        } catch (Exception ee) {
            ee.printStackTrace();
        }

        return true;

    }

    public boolean deleteDenuncia(Denuncia d) {
        String sql = "DELETE FROM denuncia WHERE id_denuncia=?";
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setLong(1, d.getId());
            stmt.execute();
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Denuncia> getDenuncia() {
        List<Denuncia> denuncia = new ArrayList<Denuncia>();
        try {
            String sql = "SELECT * FROM denuncia";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();//serve para tirar os dados do banco de dados
            while (rs.next()) {
                Denuncia u = new Denuncia();
                u.setEnd(rs.getString("endereco"));
                u.setDes(rs.getString("descricao"));
                u.setGravidade(rs.getString("gravidade"));
                u.setMate(rs.getString("material"));
                u.setImagem(rs.getString("imagem"));
                u.setId(rs.getLong("id_denuncia"));
               denuncia.add(u);
            }
            rs.close();
            stmt.close();

        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return denuncia;

    }
}
