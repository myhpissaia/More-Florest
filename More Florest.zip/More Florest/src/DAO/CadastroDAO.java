/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Cadastro;
import Model.Denuncia;
import Model.Dica;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author < Leticia e Mylena >
 */
public class CadastroDAO {

    private Connection conexao;

    public CadastroDAO() {
        this.conexao = new ConnectionFactory().getConnection();
    }

    public void insereCadastro(Cadastro u) {
        try {
            String sql = "INSERT INTO cadastro (nome,endereco,telefone,email,usuario,senha,comsenha) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, u.getNome());
            stmt.setString(2, u.getEndereco());
            stmt.setString(3, u.getTelefone());
            stmt.setString(4, u.getEmail());
            stmt.setString(5, u.getUser());
            stmt.setString(6, u.getSenha());
            stmt.setString(7, u.getComsenha());
            stmt.execute();
            conexao.close();

        } catch (SQLException ex) {
            Logger.getLogger(CadastroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
public void update(Cadastro u) throws SQLException {
        String sql = "UPDATE cadastro SET nome=?,endereco=?telefone=?,email=?,usuario=?,senha=?,comsenha=?WHERE id =?";
        PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, u.getNome());
            stmt.setString(2, u.getEndereco());
            stmt.setString(3, u.getTelefone());
            stmt.setString(4, u.getEmail());
            stmt.setString(5, u.getUser());
            stmt.setString(6, u.getSenha());
            stmt.setString(7, u.getComsenha());
            stmt.execute();
        
        stmt.execute();
        conexao.close();

    }
  public boolean deleteCadastro(Cadastro d) {
         String sql = "DELETE FROM cadastro WHERE id=?;";
         try{
             PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setLong(1, d.getId());
            stmt.execute();
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DicasDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    public List<Cadastro> getCadastro() {
        List<Cadastro> cadastro = new ArrayList<Cadastro>();
        try {
            String sql = "SELECT * FROM cadastro";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();//serve para tirar os dados do banco de dados
            while (rs.next()) {
                Cadastro u = new Cadastro();
                u.setNome(rs.getString("Nome"));
                u.setEndereco(rs.getString("Endereco"));
                u.setTelefone(rs.getString("Telefone"));
                u.setEmail(rs.getString("Email"));
                u.setUser(rs.getString("Usuario"));
                u.setSenha(rs.getString("Senha"));
                u.setComsenha(rs.getString("Comsenha"));
                cadastro.add(u);
            }
            rs.close();
            stmt.close();

        } catch (SQLException ex) {
            Logger.getLogger(CadastroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cadastro;

    }
}
