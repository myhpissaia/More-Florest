/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Dica;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author < Leticia e Mylena >
 */
public class DicasDAO {

    private Connection conexao;

    public DicasDAO() {
        this.conexao = new ConnectionFactory().getConnection();
    }

    public boolean insereDicas(Dica u) {
        try {
            String sql = "INSERT INTO dicas (material,dica) VALUES (?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, u.getMaterial());
            stmt.setString(2, u.getDica());
            
            stmt.execute();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean update(Dica m) {
        try {
            String sql = "UPDATE dicas SET material=?,dica=? WHERE id_dica =?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, m.getMaterial());
            stmt.setString(2, m.getDica());
            stmt.setLong(3, m.getId());

            stmt.execute();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;

        }

    }
    public boolean deleteDica(Dica d) {
        String sql = "DELETE FROM dicas WHERE id_dica=?;";
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setLong(1, d.getId());
            stmt.execute();
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DicasDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Dica> getDica() {
        List<Dica> dica = new ArrayList<Dica>();
        try {
            String sql = "SELECT * FROM dicas";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();//serve para tirar os dados do banco de dados
            while (rs.next()) {
                Dica u = new Dica();
                u.setId(rs.getLong("id_dica"));
                u.setMaterial(rs.getString("Material"));
                u.setDica(rs.getString("Dica"));

                dica.add(u);
            }
            rs.close();
            stmt.close();

        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dica;

    }
}
