/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.TelaDenuncia;
import Main.TelaDica;
import Main.TelaEntrada;
import Main.TelaPrincipal;
import Main.TelaTabelaDenunciaUser;
import Main.TelaTabelaDica;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaEntradaController implements Initializable {

    //Button
    @FXML
    private Button btRDenuncia;
    @FXML
    private Button btDReciclagem;
    @FXML
    private Button btVoltar;
    @FXML
    private Button btVer;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    public void sair() {
        TelaPrincipal principal = new TelaPrincipal();
        TelaEntrada.getStage().close();
        try {
            principal.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaDicaController.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public void denunciar() {
        TelaDenuncia denuncia = new TelaDenuncia();
        TelaEntrada.getStage().close();
        try {
            denuncia.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaDenunciaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void dica() {
        TelaDica dica = new TelaDica();
        TelaEntrada.getStage().close();
        try {
            dica.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaDicaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void VerDenuncia() {
        TelaTabelaDenunciaUser user = new TelaTabelaDenunciaUser();
        TelaEntrada.getStage().close();
        try {
            user.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btRDenuncia.setOnMouseClicked((MouseEvent e) -> {
            denunciar();
        });
        btRDenuncia.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                denunciar();
            }
        });
        btDReciclagem.setOnMouseClicked((MouseEvent e) -> {
            dica();
        });
        btDReciclagem.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                dica();
            }
        });
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            sair();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                sair();
            }
        });
        btVer.setOnMouseClicked((MouseEvent e) -> {
            VerDenuncia();
        });
        btVer.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                VerDenuncia();
            }
        }
        );
    }
}
