/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.TelaEntrada;
import Main.TelaEntradaAdm;
import Main.TelaPrincipal;
import Main.TelaTabelaDenuncia;
import Main.TelaTabelaDica;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaEntradaAdmController implements Initializable {

    //Button
    @FXML
    private Button btVoltar;

    @FXML
    private Button btDenuncia;

    @FXML
    private Button btDica;

    public void VerDica() {
        TelaTabelaDica dica = new TelaTabelaDica();
        TelaEntradaAdm.getStage().close();
        try {
            dica.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaAdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void VerDenuncia() {
        TelaTabelaDenuncia denuncia = new TelaTabelaDenuncia();
        TelaEntradaAdm.getStage().close();
        try {
            denuncia.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaAdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Voltar() {
        TelaPrincipal prin = new TelaPrincipal();
        TelaEntradaAdm.getStage().close();
        try {
            prin.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaAdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btDica.setOnMouseClicked((MouseEvent e) -> {
            VerDica();
        });
        btDica.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                VerDica();
            }
        });
        btDenuncia.setOnMouseClicked((MouseEvent e) -> {
            VerDenuncia();
        });
        btDenuncia.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                VerDenuncia();
            }
        });
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            Voltar();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                Voltar();
            }
        });
    }
}
