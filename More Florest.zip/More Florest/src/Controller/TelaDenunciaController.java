/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDAO;
import Main.TelaDenuncia;
import Main.TelaEntrada;
import Model.BD;
import Model.Denuncia;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaDenunciaController implements Initializable {

    //Button
    @FXML
    private Button btVoltar;
    @FXML
    private Button btEnvDenunc;
    @FXML
    private Button btDeletar;
    //Imagem
    @FXML
    private ImageView imagem;

    //TEXT FIELD 
    @FXML
    private TextField endereco;
    @FXML
    private TextField descricao;
    @FXML
    private TextField gravidade;
    @FXML
    private TextField material;
    String caminho;

    public void Endenuncia() {
        TelaEntrada entrada = new TelaEntrada();
        try {
            Denuncia den = new Denuncia();

            den.setEnd(endereco.getText());
            den.setDes(descricao.getText());
            den.setGravidade(gravidade.getText());
            den.setMate(material.getText());
            //den.setImagem(imagem.getImage());

            DenunciaDAO denuncia = new DenunciaDAO();
            denuncia.insereDenuncia(den);

            BD.getDenuncia().add(den);
            TelaDenuncia.getStage().close();
            Alert boa = new Alert(Alert.AlertType.CONFIRMATION);
            boa.setHeaderText("Denuncia salva ");
            boa.showAndWait();

            entrada.start(new Stage());

            // TelaDenuncia.getStage().close();
        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void validar() {
        String End = endereco.getText(),
                Gravidade = gravidade.getText(),
                Mate = material.getText();
        //Imagem = imagem.getImage();

        if (End == null || End.trim().isEmpty()
                || Gravidade == null || Gravidade.trim().isEmpty()
                || Mate == null || Mate.trim().isEmpty()) {
            //|| Imagem == null || Imagem.trim().isEmpty()) {
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setTitle("ERRO");
            erro.setHeaderText("Campos obrigatorios nao preenchidos  ");
            erro.setContentText("Preencha todos os campos obrigatorios ");
            endereco.setBlendMode(BlendMode.RED);
            gravidade.setBlendMode(BlendMode.RED);
            material.setBlendMode(BlendMode.RED);
            imagem.setBlendMode(BlendMode.RED);

            erro.showAndWait();

        } else {
            Endenuncia();
        }
    }

    public void voltar() {
        TelaEntrada entrada = new TelaEntrada();
        TelaDenuncia.getStage().close();

        try {
            entrada.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            voltar();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                voltar();
            }
        });
        btEnvDenunc.setOnMouseClicked((MouseEvent e) -> {
            validar();

        });
        btEnvDenunc.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                validar();

            }
        });
        imagem.setOnMouseClicked((MouseEvent e) -> {
            FileChooser chooser = new FileChooser();
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens", "*.jpg", "*.jpeg", "*.png"));
            File a = chooser.showOpenDialog(new Stage());

            if (a != null) {
                caminho = a.getAbsolutePath();
                imagem.setImage(new Image("file:///" + a.getAbsolutePath()));

            } else {
                System.out.println("nulo");
            }
        });
        btDeletar.setOnMouseClicked((MouseEvent e) -> {
            imagem.setImage(new Image("/Imagens/sem-imagem.jpg"));
            caminho = "";
        });
    }
}
