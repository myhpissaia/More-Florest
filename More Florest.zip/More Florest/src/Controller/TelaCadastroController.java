/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.CadastroDAO;
import Main.TelaCadastro;
import Main.TelaEntrada;
import Main.TelaLogin;
import Main.TelaPrincipal;
import Model.BD;
import Model.Cadastro;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.BlendMode;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author < Leticia e Mylena >
 */
public class TelaCadastroController implements Initializable {
    //BUTTON

    @FXML
    private Button btEntrar;
    @FXML
    private Button voltar;

    //TEXT FIELD
    @FXML
    private TextField id;
    @FXML
    private TextField nome;
    @FXML
    private TextField endereco;
    @FXML
    private TextField telefone;
    @FXML
    private TextField email;
    @FXML
    private TextField usuario;
    //PasswordField
    @FXML
    private PasswordField senha;
    @FXML
    private PasswordField comsenha;

    public void entrar() {
        TelaLogin login = new TelaLogin();

        try {

            Cadastro cadastros = new Cadastro();
            //cadastros.setId(id.getText());
            cadastros.setNome(nome.getText());
            cadastros.setEndereco(endereco.getText());
            cadastros.setTelefone(telefone.getText());
            cadastros.setEmail(email.getText());
            cadastros.setUser(usuario.getText());
            cadastros.setSenha(senha.getText());
            cadastros.setComsenha(comsenha.getText());

            CadastroDAO cadastro = new CadastroDAO();
            cadastro.insereCadastro(cadastros);

            if (senha.getText().equals(comsenha.getText())) {

                TelaCadastro.getStage().close();
                BD.getCadastro().add(cadastros);
                TelaCadastro.getStage().close();
                Alert boa = new Alert(Alert.AlertType.CONFIRMATION);
                boa.setHeaderText("Cadastrado realizado com Sucesso ");
                boa.showAndWait();

                login.start(new Stage());

            } else {
                Alert erro = new Alert(Alert.AlertType.ERROR);
                erro.setHeaderText("Senha e Confirmar senha nao estao iguais ");
                erro.setContentText("Tente novamente, preenchendo corretamente as senhas ");
                comsenha.setBlendMode(BlendMode.RED);
                erro.showAndWait();
            }

        } catch (Exception ex) {
            Logger.getLogger(TelaLoginController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void validar() {
        String Nome = nome.getText(),
                Email = email.getText(),
                user = usuario.getText(),
                Senha = senha.getText(),
                comfirma = comsenha.getText();

        if (Senha == null || Senha.trim().isEmpty()
                || Nome == null || Nome.trim().isEmpty()
                || Email == null || Email.trim().isEmpty()
                || user == null || user.trim().isEmpty()
                || Senha == null || Senha.trim().isEmpty()
                || comfirma == null || comfirma.trim().isEmpty()) {
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setTitle("ERRO");
            erro.setHeaderText("Campos obrigatorios nao preenchidos  ");
            erro.setContentText("Preencha todos os campos obrigatorios ");
            nome.setBlendMode(BlendMode.RED);
            email.setBlendMode(BlendMode.RED);
            usuario.setBlendMode(BlendMode.RED);
            senha.setBlendMode(BlendMode.RED);
            comsenha.setBlendMode(BlendMode.RED);
            erro.showAndWait();

        } else {
            entrar();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btEntrar.setOnMouseClicked((MouseEvent e) -> {
            validar();

        });
        btEntrar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                validar();

            }
        });
        voltar.setOnMouseClicked((MouseEvent e) -> {
            TelaPrincipal principal = new TelaPrincipal();
            TelaCadastro.getStage().close();
            try {
                principal.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaPrincipalController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        voltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                TelaPrincipal principal = new TelaPrincipal();
                TelaCadastro.getStage().close();
                try {
                    principal.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(TelaPrincipalController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }
}

