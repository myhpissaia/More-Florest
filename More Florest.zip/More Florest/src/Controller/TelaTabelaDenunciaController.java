/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDAO;
import Main.TelaAlterar;
import Main.TelaAlterarDenuncia;
import Main.TelaEntradaAdm;
import Main.TelaTabelaDenuncia;
import Model.Denuncia;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaTabelaDenunciaController implements Initializable {

    //Button
    @FXML
    private Button btAtualizar;
    @FXML
    private Button btDeletar;
    @FXML
    private Button btVoltar;
    @FXML
    private Button pdf;
    @FXML
    private Button grafico;
    @FXML
    private Button btAlterar;

    //Label
    @FXML
    private Label lbDes;
    @FXML
    private Label iId;
    @FXML
    private Label lbEn;
    @FXML
    private Label lbMate;
    @FXML
    private Label lbGra;
    //Table
    @FXML
    private TableColumn<Denuncia, Long> clnId;
    @FXML
    private TableColumn<Denuncia, String> clnGra;
    @FXML
    private TableColumn<Denuncia, String> clnDenuncia;
    @FXML
    private TableColumn<Denuncia, String> clnEnde;
    @FXML
    private TableColumn<Denuncia, String> clnMate;
    @FXML
    private TableView<Denuncia> tabela;

    //Imagem
    @FXML
    private ImageView imagem;

    private Denuncia selecionada;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       tabelamostrar();

        btDeletar.setOnMouseClicked((MouseEvent e) -> {
            deletar();
        });
        btDeletar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                deletar();
            }
        });
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            volte();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                volte();
            }
        });
        btAtualizar.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(atualizaTabela());

        });
        btAtualizar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                tabela.setItems(atualizaTabela());
            }
        });
        pdf.setOnMouseClicked((MouseEvent e) -> {
            gerarpdf();
        });
        pdf.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                gerarpdf();
            }
        });
        btAlterar.setOnMouseClicked((MouseEvent e) -> {
            alterar();
        });
        btAlterar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                alterar();

            }
        });
                tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                selecionada = (Denuncia) newValue;
                Detalhes();
            }
        });

    }

    public ObservableList<Denuncia> atualizaTabela() {
        DenunciaDAO dao = new DenunciaDAO();

        return FXCollections.observableArrayList(dao.getDenuncia());
    }

    public void alterar() {
        if (selecionada != null) {
            TelaAlterarDenuncia al = new TelaAlterarDenuncia(selecionada);
            try {
                al.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaTabelaDenunciaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setHeaderText("Selecione Algo");
            a.show();
        }
    }

    public void tabelamostrar() {
        clnId.setCellValueFactory(new PropertyValueFactory("id"));
        clnEnde.setCellValueFactory(new PropertyValueFactory("end"));
        clnDenuncia.setCellValueFactory(new PropertyValueFactory("des"));
        clnGra.setCellValueFactory(new PropertyValueFactory("gravidade"));
        clnMate.setCellValueFactory(new PropertyValueFactory("mate"));
        tabela.setItems(atualizaTabela());
    }

    public void volte() {
        TelaEntradaAdm e = new TelaEntradaAdm();
        TelaTabelaDenuncia.getStage().close();

        try {
            e.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaTabelaDenunciaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deletar() {
        if (selecionada != null) {
            DenunciaDAO dao2 = new DenunciaDAO();
            if (dao2.deleteDenuncia(selecionada)) {
                Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Deletado com sucesso");
                a.show();
                tabela.setItems(atualizaTabela());

            } else {
                Alert a = new Alert(Alert.AlertType.WARNING);
                a.setHeaderText("Nao foi possivel deletar");
                a.show();
            }
        } else {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setHeaderText("Selecione Algo");
            a.show();
        }
    }

    public void gerarpdf() {
        Document doc = new Document();
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", ".pdf"));
        File file = f.showSaveDialog(new Stage());
        if (file != null) {
            try {
                PdfWriter.getInstance(doc, new FileOutputStream(file.getAbsolutePath()));
                doc.open();
                List<Denuncia> denuncia = new DenunciaDAO().getDenuncia();
                for (int x = 0; x < denuncia.size(); x++) {
                    doc.add(new Paragraph("Id : " + denuncia.get(x).getId()));
                    doc.add(new Paragraph("Endereco : " + denuncia.get(x).getEnd()));
                    doc.add(new Paragraph("Descricao : " + denuncia.get(x).getDes()));
                    doc.add(new Paragraph("Gravidade : " + denuncia.get(x).getGravidade()));
                    doc.add(new Paragraph("Material : " + denuncia.get(x).getMate()));
                    doc.add(new Paragraph("                                     "));
                }
                doc.close();
                Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("PDF Gerado com Sucesso");
                a.show();

            } catch (DocumentException ex) {
                Logger.getLogger(TelaTabelaDenunciaController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaTabelaDenunciaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setHeaderText("Escolha algum lugar para o salvar o arquivo");
            a.show();
        }
    }

    public void Detalhes() {
        if (selecionada != null) {
            imagem.setImage(new Image("file:///" + selecionada.getImagem()));
            iId.setText(selecionada.getId().toString());
            lbEn.setText(selecionada.getEnd());
            lbDes.setText(selecionada.getDes());
            lbGra.setText(selecionada.getGravidade());
            lbMate.setText(selecionada.getMate());
        } else {
            imagem.setImage(new Image("/Imagens/sem-imagem.jpg"));
            iId.setText("");
            lbEn.setText("");
            lbDes.setText("");
            lbGra.setText("");
            lbMate.setText("");

        }
    }
}