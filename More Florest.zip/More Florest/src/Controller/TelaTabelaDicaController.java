/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DicasDAO;
import Main.TelaAlterar;
import Main.TelaEntrada;
import Main.TelaEntradaAdm;
import Main.TelaGraficoDica;
import Main.TelaPrincipal;
import Main.TelaTabelaDica;
import Model.Dica;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author  < Leticia e Mylena >
 */
public class TelaTabelaDicaController implements Initializable {

    //colunas
    @FXML
    private TableView<Dica> tabela;
    @FXML
    private TableColumn<Dica, Long> clnId;
    @FXML
    private TableColumn<Dica, String> clnMaterial;
    @FXML
    private TableColumn<Dica, String> clnDica;
    //botao
    @FXML
    private Button btDeletar;
    @FXML
    private Button btAlterar;
    @FXML
    private Button btAtualizar;
    @FXML
    private Button btVoltar;
    @FXML
    private Button pdf;
    @FXML
    private Button grafico;
    //Label
    @FXML
    private Label iMaterial;
    @FXML
    private Label iId;
    @FXML
    private Label iDica;

    //selecionar
    private Dica selecionada;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        clnId.setCellValueFactory(new PropertyValueFactory("id"));
        clnMaterial.setCellValueFactory(new PropertyValueFactory("material"));
        clnDica.setCellValueFactory(new PropertyValueFactory("dica"));
        tabela.setItems(atualizaTabela());

        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                selecionada = (Dica) newValue;
                Detalhes();
            }
        });
        btDeletar.setOnMouseClicked((MouseEvent e) -> {
            deletar();
        });
        btDeletar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                deletar();
            }
        });
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            volte();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                volte();
            }
        });
        btAtualizar.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(atualizaTabela());

        });
        btAtualizar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                tabela.setItems(atualizaTabela());
            }
        });
        pdf.setOnMouseClicked((MouseEvent e) -> {
            gerarpdf();
        });
        pdf.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                gerarpdf();
            }
        });
        btAlterar.setOnMouseClicked((MouseEvent e) -> {
            alterar();
        });
        btAlterar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                alterar();
            }
        });
        grafico.setOnMouseClicked((MouseEvent e) -> {
            gerarGrafico();
        });
        grafico.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                gerarGrafico();

            }
        });
    }

    public ObservableList<Dica> atualizaTabela() {
        DicasDAO dao = new DicasDAO();

        return FXCollections.observableArrayList(dao.getDica());
    }

    public void alterar() {
        if (selecionada != null) {
            TelaAlterar al = new TelaAlterar(selecionada);
            try {
                al.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaTabelaDicaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setHeaderText("Selecione Algo");
            a.show();
        }
    }

    public void volte() {
        TelaEntradaAdm e = new TelaEntradaAdm();
        TelaTabelaDica.getStage().close();

        try {
            e.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaTabelaDicaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deletar() {
        if (selecionada != null) {
            DicasDAO dao2 = new DicasDAO();
            if (dao2.deleteDica(selecionada)) {
                Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Deletado com sucesso");
                a.show();
                tabela.setItems(atualizaTabela());

            } else {
                Alert a = new Alert(Alert.AlertType.WARNING);
                a.setHeaderText("Nao foi possivel deletar");
                a.show();
            }
        } else {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setHeaderText("Selecione Algo");
            a.show();
        }
    }

    public void gerarpdf() {
        Document doc = new Document();
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new ExtensionFilter("PDF", ".pdf"));
        File file = f.showSaveDialog(new Stage());
        if (file != null) {
            try {
                PdfWriter.getInstance(doc, new FileOutputStream(file.getAbsolutePath()));
                doc.open();
                List<Dica> dicas = new DicasDAO().getDica();
                for (int x = 0; x < dicas.size(); x++) {
                    doc.add(new Paragraph("Id : " + dicas.get(x).getId()));
                    doc.add(new Paragraph("Material : " + dicas.get(x).getMaterial()));
                    doc.add(new Paragraph("Dica : " + dicas.get(x).getDica()));
                    doc.add(new Paragraph("                                     "));
                }
                doc.close();
                Alert a = new Alert(AlertType.CONFIRMATION);
                a.setHeaderText("Pdf Gerado com Sucesso");
                a.show();

            } catch (DocumentException ex) {
                Logger.getLogger(TelaTabelaDicaController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaTabelaDicaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            Alert a = new Alert(AlertType.WARNING);
            a.setHeaderText("Escolha algum lugar para o salvar o arquivo");
            a.show();
        }
    }

    public void gerarGrafico() {
        TelaGraficoDica grafico = new TelaGraficoDica();
        TelaTabelaDica.getStage().close();
        try {
            grafico.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaTabelaDicaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Detalhes() {
        if (selecionada != null) {
            //img.setImage(new Image(selecionada.getImagem()));
            iId.setText(selecionada.getId().toString());
            iMaterial.setText(selecionada.getMaterial());
            iDica.setText(selecionada.getDica());
        } else {
            iId.setText("");
            iMaterial.setText("");
            iDica.setText("");
        }
    }
}
