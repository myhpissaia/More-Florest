/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DicasDAO;
import Main.TelaDica;
import Main.TelaEntrada;
import Model.BD;
import Model.Dica;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaDicaController implements Initializable {
    //Button
    @FXML
    private Button btVoltar;
    @FXML
    private Button btSDica;
    //TEXT FIELD 
    @FXML
    private TextField material;
    @FXML
    private TextField envidica;

    public void SalvarDicas() {
        TelaEntrada entrada = new TelaEntrada();
        try {
            Dica di = new Dica();

            di.setMaterial(material.getText());
            di.setDica(envidica.getText());

            DicasDAO dicas = new DicasDAO();
            dicas.insereDicas(di);

            BD.getDica().add(di);
            TelaDica.getStage().close();
            Alert boa = new Alert(Alert.AlertType.CONFIRMATION);
            boa.setHeaderText("Dicas salva ");
            boa.showAndWait();

            entrada.start(new Stage());

           // TelaDica.getStage().close();

        } catch (Exception ex) {
            Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            TelaEntrada entrada = new TelaEntrada();
            TelaDica.getStage().close();
            try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                TelaEntrada entrada = new TelaEntrada();
                TelaDica.getStage().close();
                try {
                    entrada.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        btSDica.setOnMouseClicked((MouseEvent e) -> {
            SalvarDicas();
        });
        btSDica.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                SalvarDicas();

            }
        });

    }
}
