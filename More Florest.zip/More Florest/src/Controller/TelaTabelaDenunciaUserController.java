/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDAO;
import Main.TelaEntrada;
import Main.TelaTabelaDenunciaUser;
import Model.Denuncia;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaTabelaDenunciaUserController implements Initializable {

    //Button
    @FXML
    private Button btAtualizar;
    @FXML
    private Button btVoltar;
    
    //Label
    @FXML
    private Label lbDes;
    @FXML
    private Label iId;
    @FXML
    private Label lbEn;
    @FXML
    private Label lbMate;
    @FXML
    private Label lbGra;
    //Table
    @FXML
    private TableColumn<Denuncia, Long> clnId;
    @FXML
    private TableColumn<Denuncia, String> clnGra;
    @FXML
    private TableColumn<Denuncia, String> clnDenuncia;
    @FXML
    private TableColumn<Denuncia, String> clnEnde;
    @FXML
    private TableColumn<Denuncia, String> clnMate;
    @FXML
    private TableView<Denuncia> tabela;

    //Imagem
    @FXML
    private ImageView imagem;

    private Denuncia selecionada;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        clnId.setCellValueFactory(new PropertyValueFactory("id"));
        clnEnde.setCellValueFactory(new PropertyValueFactory("end"));
        clnDenuncia.setCellValueFactory(new PropertyValueFactory("des"));
        clnGra.setCellValueFactory(new PropertyValueFactory("gravidade"));
        clnMate.setCellValueFactory(new PropertyValueFactory("mate"));
        tabela.setItems(atualizaTabela());

        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                selecionada = (Denuncia) newValue;
                Detalhes();
            }
        });
       
        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            volte();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                volte();
            }
        });
        btAtualizar.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(atualizaTabela());

        });
        btAtualizar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                tabela.setItems(atualizaTabela());
            }
        });
    }

    public ObservableList<Denuncia> atualizaTabela() {
        DenunciaDAO dao = new DenunciaDAO();

        return FXCollections.observableArrayList(dao.getDenuncia());
    }

    public void volte() {
        TelaEntrada e = new TelaEntrada();
        TelaTabelaDenunciaUser.getStage().close();

        try {
            e.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TelaTabelaDenunciaUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Detalhes() {
        if (selecionada != null) {
            imagem.setImage(new Image("file:///"+selecionada.getImagem()));
            iId.setText(selecionada.getId().toString());
            lbEn.setText(selecionada.getEnd());
            lbDes.setText(selecionada.getDes());
            lbGra.setText(selecionada.getGravidade());
            lbMate.setText(selecionada.getMate());
        } else {
            imagem.setImage(new Image (""));
            iId.setText("");
            lbEn.setText("");
            lbDes.setText("");
            lbGra.setText("");
            lbMate.setText("");
            
        }
    }
}   
    

