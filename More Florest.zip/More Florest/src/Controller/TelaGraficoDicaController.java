/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaGraficoDicaController implements Initializable {

    @FXML
    private PieChart pGrafico;

    public void initGraph() {
        pGrafico.getData().addAll(new PieChart.Data("Material",1));
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

}
