/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DicasDAO;
import Main.TelaAlterar;
import Model.Dica;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author  < Leticia e Mylena >
 */
public class TelaAlterarController implements Initializable {

//Button
    @FXML
    private Button btVoltar;
    @FXML
    private Button btAu;
    //Text
    @FXML
    private TextField lbMaterial;
    @FXML
    private TextField envidica;
    //Label
    @FXML
    private Label id;
    @FXML
    private Label ibId;

    private static Dica dica;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initPerson();

        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            TelaAlterar.getStage().close();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                TelaAlterar.getStage().close();
            }
        });
        btAu.setOnMouseClicked((MouseEvent e) -> {
            atualiza();
        });
        btAu.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                atualiza();
            }
        });
    }

    public void initPerson() {
        ibId.setText(dica.getId() + "");
        envidica.setText(dica.getDica());
        lbMaterial.setText(dica.getMaterial());
    }

    public static Dica getDica() {
        return dica;
    }

    public static void setDica(Dica d) {
        TelaAlterarController.dica = d;

    }

    public void atualiza() {
        DicasDAO dao = new DicasDAO();

        Long id = Long.parseLong(ibId.getText());
        String material = lbMaterial.getText(), dica = envidica.getText();

        Dica d = new Dica(id, material, dica);
        if (dao.update(d)) {
            Alert al = new Alert(AlertType.CONFIRMATION);
            al.setHeaderText("Atualizado com sucesso ");
            TelaAlterar.getStage().close();
            al.show();

        } else {
            Alert al = new Alert(AlertType.ERROR);
            al.setHeaderText(" Erro ao Atualizar ");
            al.show();
        }

    }
}
