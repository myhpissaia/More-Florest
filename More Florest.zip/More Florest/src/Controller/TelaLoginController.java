/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.CadastroDAO;
import Main.TelaEntrada;
import Main.TelaEntradaAdm;
import Main.TelaLogin;
import Main.TelaTabelaDica;
import Model.Cadastro;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaLoginController implements Initializable {

    @FXML
    private Button btEntrar;
    @FXML
    private TextField Login;
    @FXML
    private PasswordField Senha;

    public void Entrar() {

        if (Login.equals("") || Senha.equals("")) {

            Alert erro = new Alert(Alert.AlertType.WARNING);
            erro.setTitle("Erro!");
            erro.setHeaderText("Campos vazios!");
            erro.setContentText("Preencha todos os campos");
            erro.showAndWait();

        } else if (Login.getText().equals("admin") && Senha.getText().equals("admin123")) {
            TelaEntradaAdm entrada = new TelaEntradaAdm();
            try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaLoginController.class.getName()).log(Level.SEVERE, null, ex);
            }

            TelaLogin.getStage().close();
        } else {
            CadastroDAO dao = new CadastroDAO();
            ObservableList<Cadastro> cadastro = FXCollections.observableArrayList(dao.getCadastro());

            for (int x = 0; x < cadastro.size(); x++) {
                if (cadastro.get(x).getUser().equals(Login.getText()) && cadastro.get(x).getSenha().equals(Senha.getText())) {
                    TelaEntrada entrada = new TelaEntrada();
                    try {
                        entrada.start(new Stage());
                    } catch (Exception ex) {
                        Logger.getLogger(TelaLoginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    TelaLogin.getStage().close();
                } else if (x + 1 == cadastro.size()) {
                    Alert erro = new Alert(AlertType.ERROR);
                    erro.setHeaderText("Usuario ou senha incorretos. Tente novamente");
                    erro.show();
                }
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btEntrar.setOnMouseClicked((MouseEvent e) -> {
            Entrar();

        });
        btEntrar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                Entrar();

            }
        });
        Senha.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                Entrar();

            }
        });
    }
}

