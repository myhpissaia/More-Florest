/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDAO;
import DAO.DicasDAO;
import Main.TelaAlterar;
import Main.TelaAlterarDenuncia;
import Model.Denuncia;
import Model.Dica;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaAlterarDenunciaController implements Initializable {

    //Button
    @FXML
    private Button btVoltar;
    @FXML
    private Button btDeletar;
    @FXML
    private Button btAtu;
    //Label
    @FXML
    private Label lbID;
    @FXML
    private Label id;
    //Text
    @FXML
    private TextField tEndereco;
    @FXML
    private TextField tMaterial;
    @FXML
    private TextField tGravidade;
    @FXML
    private TextField tDescricao;
    //Image
    @FXML
    private ImageView imagem;

    private static Denuncia denuncia1;
    private String caminhoFoto;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initPerson();

        btVoltar.setOnMouseClicked((MouseEvent e) -> {
            TelaAlterarDenuncia.getStage().close();
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                TelaAlterarDenuncia.getStage().close();
            }
        });
        btAtu.setOnMouseClicked((MouseEvent e) -> {
            atualiza();
        });
        btAtu.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                atualiza();
            }
        });
        imagem.setOnMouseClicked((MouseEvent e) -> {
            selecionarFoto();
        });
    }

    public void initPerson() {
        imagem.setImage(new Image("file:///" + getDenuncia1().getImagem()));
        lbID.setText(getDenuncia1().getId() + "");
        tEndereco.setText(getDenuncia1().getEnd());
        tDescricao.setText(getDenuncia1().getDes());
        tGravidade.setText(getDenuncia1().getGravidade());
        tMaterial.setText(getDenuncia1().getMate());
        caminhoFoto = getDenuncia1().getImagem();

    }

    public static Denuncia getDenuncia1() {
        return denuncia1;
    }

    public static void setDenuncia1(Denuncia d) {
        TelaAlterarDenunciaController.denuncia1 = d;

    }

    public void selecionarFoto() {
        
            FileChooser chooser = new FileChooser();
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens", "*.jpg", "*.jpeg", "*.png"));
            File a = chooser.showOpenDialog(new Stage());

            if (a != null) {
                caminhoFoto = a.getAbsolutePath();
                imagem.setImage(new Image("file:///" + a.getAbsolutePath()));

            } else {
                System.out.println("nulo");
            }
    }

    public void atualiza() {
        Long id = Long.parseLong(lbID.getText());
        String endereco = tEndereco.getText(), descricao = tDescricao.getText(), gravidade = tGravidade.getText(), material = tMaterial.getText();
        DenunciaDAO dao = new DenunciaDAO();
        Denuncia de = new Denuncia(id, endereco, descricao, gravidade, material, caminhoFoto);
        if (dao.update(de)) {
            Alert al = new Alert(Alert.AlertType.CONFIRMATION);
            al.setHeaderText("Atualizado com sucesso ");
            TelaAlterarDenuncia.getStage().close();
            al.show();

        } else {
            Alert al = new Alert(Alert.AlertType.ERROR);
            al.setHeaderText(" Erro ao Atualizar ");
            al.show();
        }

    }
}
