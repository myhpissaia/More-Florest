/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Controller.TelaAlterarController;
import Controller.TelaAlterarDenunciaController;
import Model.Denuncia;
import Model.Dica;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author < Leticia e Mylena >
 */
public class TelaAlterarDenuncia extends Application {

    private static Stage stage;

    public TelaAlterarDenuncia(Denuncia d) {
        TelaAlterarDenunciaController.setDenuncia1(d);

    }

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/TelaAlterarDenuncia.fxml"));

        Scene scene = new Scene(root);
        stage.setTitle("Alterar Denuncia");
        stage.setScene(scene);
        stage.show();
        TelaAlterarDenuncia.stage = stage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public static Stage getStage() {
        return TelaAlterarDenuncia.stage;
    }

    public void setStage(Stage s) {
        TelaAlterarDenuncia.stage = s;
    }
}
