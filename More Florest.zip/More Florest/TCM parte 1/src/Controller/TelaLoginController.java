/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.TelaEntrada;
import Main.TelaLogin;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaLoginController implements Initializable {

    @FXML
    private Button btEntrar;
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btEntrar.setOnMouseClicked((MouseEvent e) -> {
            
            TelaEntrada entrada = new TelaEntrada();
            TelaLogin.getStage().close();

            try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btEntrar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                TelaEntrada entrada = new TelaEntrada();

                TelaLogin.getStage().close();

                try {
                    entrada.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
    }
}
