/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.CadastroDAO;
import Main.TelaCadastro;
import Main.TelaLogin;
import Main.TelaPrincipal;
import Model.BD;
import Model.Cadastro;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author < Leticia e Mylena >
 */
public class TelaCadastroController implements Initializable {
  //BUTTON

    @FXML
    private Button btEntrar;
    @FXML
    private Button voltar;

    //TEXT FIELD
    @FXML
    private TextField id;
    @FXML
    private TextField nome;
    @FXML
    private TextField endereco;
    @FXML
    private TextField telefone;
    @FXML
    private TextField email;
    @FXML
    private TextField usuario;
    @FXML
    private PasswordField senha;
    @FXML
    private PasswordField comsenha;
     
    
    public void entrar(){
    TelaLogin login = new TelaLogin();

        try {
                Cadastro cadastros = new Cadastro();
                //cadastros.setId(id.getText());
                cadastros.setNome(nome.getText());
                cadastros.setEndereco(endereco.getText());
                cadastros.setTelefone(telefone.getText());
                cadastros.setEmail(email.getText());
                cadastros.setUser(usuario.getText());
                cadastros.setSenha(senha.getText());
                cadastros.setComsenha(comsenha.getText());

                CadastroDAO cadastro = new CadastroDAO();
                cadastro.insereCadastro(cadastros);

                BD.getCadastro().add(cadastros);
                TelaCadastro.getStage().close();
                Alert boa=new Alert (Alert .AlertType.CONFIRMATION);
                boa.setHeaderText("Cadastrado realizado com Sucesso ");
                boa.showAndWait();
                
                login.start(new Stage());
                
                
            } catch (Exception ex) {
                Logger.getLogger(TelaLoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btEntrar.setOnMouseClicked((MouseEvent e) -> {
            entrar();
            /*TelaLogin login = new TelaLogin();
            TelaCadastro.getStage().close();
            try {
                login.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaLoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            CadastroDAO dao1 = new CadastroDAO();
            List<Cadastro> z = dao1.getList();

            for (int x = 0; x < z.size(); x++) {
                z.get(x).MostrarCadastro();

            }*/
        });
        btEntrar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                entrar();
               /* TelaLogin login = new TelaLogin();
                TelaCadastro.getStage().close();
                try {
                    login.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(TelaLoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
                CadastroDAO dao = new CadastroDAO();
                List<Cadastro> z = dao.getList();

                for (int x = 0; x < z.size(); x++) {
                    z.get(x).MostrarCadastro();

                }*/
            }
        });
        voltar.setOnMouseClicked((MouseEvent e) -> {
            TelaPrincipal principal = new TelaPrincipal();
            TelaCadastro.getStage().close();
            try {
                principal.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaPrincipalController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        voltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                TelaPrincipal principal = new TelaPrincipal();
                TelaCadastro.getStage().close();
                try {
                    principal.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(TelaPrincipalController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }
}
 /*Principal Principal = new Principal();
                    Login.getStage().close();*/
