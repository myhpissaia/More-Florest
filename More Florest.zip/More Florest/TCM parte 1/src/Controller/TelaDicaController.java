/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.TelaDica;
import Main.TelaEntrada;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author < Leticia e Mylena >
 */
public class TelaDicaController implements Initializable {
    @FXML 
    private Button btVoltar;
    @FXML 
    private Button btSDica;
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btVoltar.setOnMouseClicked((MouseEvent e) ->{
            TelaEntrada entrada = new TelaEntrada();
            TelaDica.getStage().close();
        try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btVoltar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
               TelaEntrada entrada = new TelaEntrada();
            TelaDica.getStage().close();
        try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }});
        btSDica.setOnMouseClicked((MouseEvent e) ->{
            TelaEntrada entrada = new TelaEntrada();
            TelaDica.getStage().close();
        try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btSDica.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
               TelaEntrada entrada = new TelaEntrada();
            TelaDica.getStage().close();
        try {
                entrada.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaEntradaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }});
        
            
    }
}    
    

