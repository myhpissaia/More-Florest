/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author < Leticia e Mylena >
 */
public class Denuncia {
    private String end;
    private String des;
    private String gravidade;
    private String mate;

    /**
     * @return the end
     */
    public String getEnd() {
        return end;
    }

    /**
     * @param end the end to set
     */
    public void setEnd(String end) {
        this.end = end;
    }

    /**
     * @return the des
     */
    public String getDes() {
        return des;
    }

    /**
     * @param des the des to set
     */
    public void setDes(String des) {
        this.des = des;
    }

    /**
     * @return the gravidade
     */
    public String getGravidade() {
        return gravidade;
    }

    /**
     * @param gravidade the gravidade to set
     */
    public void setGravidade(String gravidade) {
        this.gravidade = gravidade;
    }

    /**
     * @return the mate
     */
    public String getMate() {
        return mate;
    }

    /**
     * @param mate the mate to set
     */
    public void setMate(String mate) {
        this.mate = mate;
    }
    public void MostrarDenuncia(){
        System.out.println("");
        System.out.println("DENUNCIA");
        System.out.println("Endereco:"+getEnd());
        System.out.println("Descricao:"+getDes());
        System.out.println("Gravidade:"+getGravidade());
        System.out.println("Material:"+getMate());
        System.out.println("");
    }
}
