/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author < Leticia e Mylena >
 */
public class Dica {
    private String material;
    private String dica;

    /**
     * @return the material
     */
    public String getMaterial() {
        return material;
    }

    /**
     * @param material the material to set
     */
    public void setMaterial(String material) {
        this.material = material;
    }

    /**
     * @return the dica
     */
    public String getDica() {
        return dica;
    }

    /**
     * @param dica the dica to set
     */
    public void setDica(String dica) {
        this.dica = dica;
    }
    public void MostrarDica(){
        System.out.println("");
        System.out.println("DICA");
        System.out.println("Material:"+getMaterial());
        System.out.println("Dica:"+getDica());
        System.out.println("");
    }
    
}
