/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author < Leticia e Mylena >
 */
public class Cadastro {
    private String id;
    private String nome;
    private String endereco;
    private String telefone;
    private String email;
    private String user;
    private String senha;
    private String comsenha;
   
    
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the enderenco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param enderenco the enderenco to set
     */
    public void setEndereco(String enderenco) {
        this.endereco = enderenco;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the comsenha
     */
    public String getComsenha() {
        return comsenha;
    }

    /**
     * @param comsenha the comsenha to set
     */
    public void setComsenha(String comsenha) {
        this.comsenha = comsenha;
    }
    public void MostrarCadastro() {
        System.out.println("");
        System.out.println("CADASTRO");
        System.out.println("ID:"+getId());
        System.out.println("Nome: " + getNome());
        System.out.println("Endereco: " + getEndereco());
        System.out.println("Telefone: " + getTelefone());
        System.out.println("Email: " + getEmail());
        System.out.println("Usuario: " + getUser());
        System.out.println("Senha: " + getSenha());
        System.out.println("Comfirmar senha: " + getComsenha());
        System.out.println("");

    }
}
